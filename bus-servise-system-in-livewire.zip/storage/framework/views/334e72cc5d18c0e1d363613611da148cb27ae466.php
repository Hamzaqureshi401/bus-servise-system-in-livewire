<div>
    <div class="row mb-2 mb-xl-3">
        <div class="col-auto d-none d-sm-block">
            <h3><strong><?php echo e($lang->data['driver']??'Driver'); ?></strong></h3>
        </div>

        <div class="col-auto ms-auto text-end mt-n1">
            <?php if(Auth::user()->can('add_driver')): ?>
            <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#ModalCustomer" wire:click="resetFields"><?php echo e($lang->data['new_driver']??'New
                Driver'); ?></a>
            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card p-0">
                <div class="card-body p-0">
                    <table id="table" class="table datatable table-striped table-bordered mb-0">
                        <thead class="bg-secondary-light">
                            <tr>
                                <th class="tw-5"><?php echo e($lang->data['sl']??'Sl'); ?></th>
                                <th class="tw-20"><?php echo e($lang->data['name']??'Name'); ?></th>
                                <th class="tw-20"><?php echo e($lang->data['mobile_no']??'Mobile No.'); ?></th>
                                <th class="tw-20"><?php echo e($lang->data['registration_no']??'Registration No'); ?></th>
                                <th class="tw-20"><?php echo e($lang->data['monthly_salary']??'Monthly Salary'); ?></th>
                                <th class="tw-20"><?php echo e($lang->data['Status']??'Status'); ?></th>
                                <th class="tw-10"><?php echo e($lang->data['actions']??'Actions'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->mobile_no); ?></td>
                                <td><?php echo e(date('d/m/Y', strtotime($item->registration_date))); ?></td>
                                <td><?php echo e($item->monthly_salary); ?></td>
                               <td>
                                    <?php if($item->status == 1): ?>
                                        <span style="font-weight: bold; color: blue;">Booked</span>
                                    <?php else: ?>
                                        <span style="font-weight: bold; color: green;">Free</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(Auth::user()->can('edit_driver')): ?>
                                    <a href="#" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#EditModalCustomer" wire:click='edit(<?php echo e($item); ?>)'><?php echo e($lang->data['edit']??'Edit'); ?></a>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->can('edit_driver')): ?>
                                    <a href="#" class="btn btn-sm btn-danger" wire:click="delete(<?php echo e($item); ?>)"><?php echo e($lang->data['delete']??'Delete'); ?></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php if(count($drivers) == 0): ?>
                        <?php if (isset($component)) { $__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\NoDataComponent::class, ['message' => 'No Customers were found']); ?>
<?php $component->withName('no-data-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['messageindex' => 'no_customers_found']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0)): ?>
<?php $component = $__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0; ?>
<?php unset($__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="ModalCustomer" tabindex="-1" role="dialog" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e($lang->data['add_new_driver']??'Add New Driver'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="mb-3 col-md-6">
                            <label class="form-label"><?php echo e($lang->data['name']??'Name'); ?> <span class="text-danger"><strong>*</strong></span></label>
                            <input type="text" class="form-control" id="inputEmail4" placeholder="<?php echo e($lang->data['name']??'Name'); ?>" wire:model="name">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-md-6">
                            <label class="form-label"><?php echo e($lang->data['registraion_date']??'Registration Date'); ?><span class="text-danger"><strong>*</strong></label>
                            <input type="date" class="form-control"  wire:model="registration_date">
                            <?php $__errorArgs = ['registration_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div> 
                </div>
                <div class="row">
                    
                    <div class="mb-3 col-md-6">
                        <label class="form-label"><?php echo e($lang->data['mobile_number']??'Mobile Number'); ?><span
                                class="text-danger"></span></label>
                        <input type="text" class="form-control" placeholder="<?php echo e($lang->data['mobile']??'mobile_no'); ?>" wire:model="mobile_no">
                        <?php $__errorArgs = ['mobile_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3 col-md-6">
                        <label class="form-label"><?php echo e($lang->data['monthly_salary']??'Monthly Salary'); ?></label>
                        <input type="text"class="form-control resize-none" placeholder="<?php echo e($lang->data['monthly_salary']??'Monthly Salary'); ?>" wire:model="monthly_salary">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e($lang->data['close']??'Close'); ?></button>
                    <button type="button" class="btn btn-success" wire:click="create"><?php echo e($lang->data['save']??'Save'); ?></button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="EditModalCustomer" tabindex="-1" role="dialog" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e($lang->data['edit_driver']??'Edit Driver'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="mb-3 col-md-6">
                            <label class="form-label"><?php echo e($lang->data['name']??'Name'); ?> <span class="text-danger"><strong>*</strong></span></label>
                            <input type="text" class="form-control" id="inputEmail4" placeholder="<?php echo e($lang->data['name']??'Name'); ?>" wire:model="name">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-md-6">
                            <label class="form-label"><?php echo e($lang->data['mobile_number']??'Mobile Number'); ?><span
                                    class="text-danger"></span></label>
                            <input type="text" class="form-control" placeholder="<?php echo e($lang->data['mobile']??'mobile_no'); ?>" wire:model="mobile_no">
                            <?php $__errorArgs = ['mobile_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo e($lang->data['registraion_date']??'Registration Date'); ?></label>
                        <input type="date" class="form-control"  wire:model="registration_date">
                        <?php $__errorArgs = ['registraion_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo e($lang->data['monthly_salary']??'Monthly Salary'); ?></label>
                        <input type="text"class="form-control resize-none" placeholder="<?php echo e($lang->data['monthly_salary']??'Monthly Salary'); ?>" wire:model="monthly_salary">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e($lang->data['close']??'Close'); ?></button>
                    <button type="button" class="btn btn-success" wire:click="update"><?php echo e($lang->data['save']??'Save'); ?></button>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\bus driver servise system livewire\bus-servise-system-in-livewire\resources\views/livewire/admin/driver/driver.blade.php ENDPATH**/ ?>