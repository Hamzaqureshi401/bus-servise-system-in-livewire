<div>
    <!-- <center>
                            <div>
                                <?php
                                $logo = '/uploads/logo/1698697749.png';
                                ?>
                                <img src="<?php echo e($logo); ?>" alt="Company Logo" style="width: auto; height: auto; max-width: 60%; max-height: 60%;">
                            </div>
                       </center>
<br> -->
<div class="col-auto d-none d-sm-block">
        <h3><strong><?php echo e($lang->data['expense'] ?? 'Payments'); ?></strong></h3>
    </div>

    <table class="table table-striped">
        <thead>
            <tr>
                <!-- <th>Sl</th>
                 --><th>Date</th>
                <th>Driver</th>
                <th>Added By</th>
                <!-- <th>Vehicle Assigning</th> -->
                <th>Purpose</th>
                <th>Amount</th>
                <th>Company</th>
                <!-- <th>Vehicle</th> -->
                <th>Vehicle File No</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $data['payments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>

                    <!-- <td><?php echo e($loop->index + 1); ?></td>
                     --><td><?php echo e(date('d/m/Y', strtotime($payment->created_at))); ?></td>
                            
                    <td><?php echo e($payment->driver->name); ?></td>
                    <td><?php echo e($payment->user->name ?? '--'); ?></td>
                    
                    <!-- <td><?php echo e($payment->vehicle_assigning_id); ?></td>
                     --><td><?php echo e($payment->purpose); ?></td>
                    <td><?php echo e($payment->amount); ?></td>
                    <td><?php echo e($payment->company->name); ?></td>
                    <!-- <td><?php echo e($payment->vehicle->plate_no); ?>/<?php echo e($payment->vehicle->owner_name); ?>/<?php echo e($payment->vehicle->vehicle_model); ?>/<?php echo e($payment->vehicle->fuel_type); ?></td>
                     --><td><?php echo e($payment->vehicle_file_no); ?></td>
                    <td><?php echo e($payment->description); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-center">No payments found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Pagination links -->
    <div class="mt-4">
        <?php echo e($data['payments']->links()); ?>

    </div>
    <div class="col-auto d-none d-sm-block">
        <h3><strong><?php echo e($lang->data['expense'] ?? 'Expences'); ?></strong></h3>
    </div>
<table class="table table-striped table-bordered mb-0">
                        <thead class="bg-secondary-light">
                        <tr>
                            <!-- <th class="tw-5"><?php echo e($lang->data['sl'] ?? 'Sl'); ?></th>
                             --><th class="tw-15"><?php echo e($lang->data['date'] ?? 'Date'); ?></th>
                            <th>Added By</th>
                
                            <th class="tw-20"><?php echo e($lang->data['vehicle_plate_no'] ?? 'File no. & Company'); ?></th>
                            <th class="tw-15"><?php echo e($lang->data['expense_type'] ?? 'Driver '); ?></th>
                            <th class="tw-15"><?php echo e($lang->data['expense_type'] ?? 'Expense Type '); ?></th>
                            <th class="tw-15"><?php echo e($lang->data['amount'] ?? 'Amount'); ?></th>
                            <th class="tw-15"><?php echo e($lang->data['description'] ?? 'Description'); ?></th>
                            <!-- <th class="tw-15"><?php echo e($lang->data['actions'] ?? 'Actions'); ?></th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data['expenses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <!-- <td><?php echo e($loop->index + 1); ?></td>
                             --><td><?php echo e(date('d/m/Y', strtotime($item->date))); ?></td>
                            <td><?php echo e($item->user->name ?? '--'); ?></td>
                                
                            <td><?php echo e($item->assigning->vehicle->file_no); ?>-<?php echo e($item->assigning->company->name); ?> </td>
                            <td><strong><?php echo e($item->assigning->driver->name); ?></strong></td>

                            <td><span class="badge bg-dark"><?php echo e($item->expensetype->name); ?></span></td>
                            <td><?php echo e($item->amount); ?></td>
                             <td><?php echo e($item->description); ?></td>
                           
                            <!-- <td>
                               
                                <?php if(Auth::user()->can('edit_expenses')): ?>
                                <a href="<?php echo e(route('admin.edit_expense',$item->id)); ?>" class="btn btn-sm btn-primary"><?php echo e($lang->data['edit'] ?? 'Edit'); ?></a>
                                <?php endif; ?>

                                <?php if(Auth::user()->can('delete_expenses')): ?>
                                <a href="#" class="btn btn-sm btn-danger" wire:click="delete(<?php echo e($item); ?>)"><?php echo e($lang->data['delete'] ?? 'Delete'); ?></a>
                                <?php endif; ?>

                            </td> -->
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php if(count($data['expenses']) == 0): ?>
                    <?php if (isset($component)) { $__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\NoDataComponent::class, ['message' => ''.e($lang->data['no_products_found'] ?? 'No Expenses were found..').'']); ?>
<?php $component->withName('no-data-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0)): ?>
<?php $component = $__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0; ?>
<?php unset($__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0); ?>
<?php endif; ?>
                <?php endif; ?>
<div class="col-auto d-none d-sm-block">
        <h3><strong><?php echo e($lang->data['salary'] ?? 'Salary'); ?></strong></h3>
    </div>
<table class="table table-striped table-bordered mb-0">
                        <thead class="bg-secondary-light">
                        <tr>
                            <!-- <th class="tw-5"><?php echo e($lang->data['sl'] ?? 'Sl'); ?></th>
                             --><th class="tw-15"><?php echo e($lang->data['date'] ?? 'Date'); ?></th>
                            <th>Added By</th>
                
                            <th class="tw-20"><?php echo e($lang->data['vehicle_plate_no'] ?? 'File no. & Company'); ?></th>
                            <th class="tw-15"><?php echo e($lang->data['expense_type'] ?? 'Driver '); ?></th>
                            <th class="tw-15"><?php echo e($lang->data['expense_type'] ?? 'Expense Type '); ?></th>
                            <th class="tw-15"><?php echo e($lang->data['amount'] ?? 'Amount'); ?></th>
                            <th class="tw-15"><?php echo e($lang->data['description'] ?? 'Description'); ?></th>
                            <!-- <th class="tw-15"><?php echo e($lang->data['actions'] ?? 'Actions'); ?></th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data['sellary']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <!-- <td><?php echo e($loop->index + 1); ?></td>
                             --><td><?php echo e(date('d/m/Y', strtotime($item->date))); ?></td>
                            <td><?php echo e($item->user->name ?? '--'); ?></td>
                                
                            <td><?php echo e($item->assigning->vehicle->file_no); ?>-<?php echo e($item->assigning->company->name); ?> </td>
                            <td><strong><?php echo e($item->assigning->driver->name); ?></strong></td>

                            <td><span class="badge bg-dark"><?php echo e($item->expensetype->name); ?></span></td>
                            <td><?php echo e($item->amount); ?></td>
                             <td><?php echo e($item->description); ?></td>
                           
                            <!-- <td>
                               
                                <?php if(Auth::user()->can('edit_expenses')): ?>
                                <a href="<?php echo e(route('admin.edit_expense',$item->id)); ?>" class="btn btn-sm btn-primary"><?php echo e($lang->data['edit'] ?? 'Edit'); ?></a>
                                <?php endif; ?>

                                <?php if(Auth::user()->can('delete_expenses')): ?>
                                <a href="#" class="btn btn-sm btn-danger" wire:click="delete(<?php echo e($item); ?>)"><?php echo e($lang->data['delete'] ?? 'Delete'); ?></a>
                                <?php endif; ?>

                            </td> -->
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php if(count($data['sellary']) == 0): ?>
                    <?php if (isset($component)) { $__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\NoDataComponent::class, ['message' => ''.e($lang->data['no_products_found'] ?? 'No Expenses were found..').'']); ?>
<?php $component->withName('no-data-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0)): ?>
<?php $component = $__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0; ?>
<?php unset($__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0); ?>
<?php endif; ?>
                <?php endif; ?>
                <div class="col-auto d-none d-sm-block">
            <h3><strong><?php echo e($lang->data['maintainance']??'Maintainance'); ?></strong></h3>
        </div>
<table class="table datatable table-striped table-bordered mb-0">
                        <thead class="bg-secondary-light">
                            <tr>
                                <th class="tw-15"><?php echo e($lang->data['date'] ?? 'Date'); ?></th>
                                <td><?php echo e($item->user->name ?? '--'); ?></td>
                                 
                                 <th class="tw-15"><?php echo e($lang->data['vehicle_plate_no'] ?? 'File no. & Company'); ?></th>
                                 <th class="tw-10"><?php echo e($lang->data['vehicle_file_no'] ?? 'Driver'); ?></th>
                                <th class="tw-15"><?php echo e($lang->data['parts_type'] ?? 'Parts Type '); ?></th>
                                <th class="tw-15"><?php echo e($lang->data['amount'] ?? 'Parts Amount'); ?></th>
                                <th class="tw-15"><?php echo e($lang->data['garage_services_charges'] ?? 'Garage Services Charges'); ?></th>
                                <th class="tw-15"><?php echo e($lang->data['description'] ?? 'Description'); ?></th>
                                <th class="tw-15"><?php echo e($lang->data['total'] ?? 'Total'); ?></th>
                                
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['maintainances']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(date('d/m/Y', strtotime($item->date))); ?></td>
                                <td><?php echo e($item->user->name ?? '--'); ?></td>
                                
                                <td><?php echo e($item->assigning->vehicle->file_no); ?>-<?php echo e($item->assigning->company->name); ?> </td>
                                <td><strong><?php echo e($item->assigning->driver->name); ?></strong></td>
                                <td><span class="badge bg-dark"><?php echo e($item->partstype->name); ?></span></td>
                                <td><?php echo e($item->payment); ?></td>
                                <td><?php echo e($item->garage_services_charges); ?></td>
                                <td><?php echo e($item->description); ?></td>
                                <td><?php echo e($item->total); ?></td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php if(count($data['maintainances']) == 0): ?>
                        <?php if (isset($component)) { $__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\NoDataComponent::class, ['message' => 'No Maintainance Record were found']); ?>
<?php $component->withName('no-data-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['messageindex' => 'not_found']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0)): ?>
<?php $component = $__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0; ?>
<?php unset($__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0); ?>
<?php endif; ?>
                    <?php endif; ?>
                <div class="col-auto d-none d-sm-block">
        <h3><strong><?php echo e($lang->data['drivres'] ?? 'Drivers'); ?></strong></h3>
    </div>
    <table class="table table-striped table-bordered mb-0">
                        <thead class="bg-secondary-light">
                            <tr>
                                <!-- <th class="tw-5"><?php echo e($lang->data['sl']??'Sl'); ?></th>
                                 --><th>Date</th>
                                <th>Added By</th>
                
                                <th class="tw-20"><?php echo e($lang->data['name']??'Name'); ?></th>
                                <th class="tw-20"><?php echo e($lang->data['mobile_no']??'Mobile No.'); ?></th>
                                <th class="tw-20"><?php echo e($lang->data['registration_no']??'Registration No'); ?></th>
                                <th class="tw-20"><?php echo e($lang->data['monthly_salary']??'Monthly Salary'); ?></th>
                                <th class="tw-20"><?php echo e($lang->data['Status']??'Status'); ?></th>
                                <!-- <th class="tw-10"><?php echo e($lang->data['actions']??'Actions'); ?></th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['drivers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <!-- <td><?php echo e($loop->index+1); ?></td>
                                 --><td><?php echo e(date('d/m/Y', strtotime($item->created_at))); ?></td>
                                <td><?php echo e($item->user->name ?? '--'); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->mobile_no); ?></td>
                                <td><?php echo e(date('d/m/Y', strtotime($item->registration_date))); ?></td>
                                <td><?php echo e($item->monthly_salary); ?></td>
                               <td>
                                    <?php if($item->status == 1): ?>
                                        <span style="font-weight: bold; color: blue;">Booked</span>
                                    <?php else: ?>
                                        <span style="font-weight: bold; color: green;">Free</span>
                                    <?php endif; ?>
                                </td>
                                <!-- <td>
                                    <?php if(Auth::user()->can('edit_driver')): ?>
                                    <a href="#" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#EditModalCustomer" wire:click='edit(<?php echo e($item); ?>)'><?php echo e($lang->data['edit']??'Edit'); ?></a>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->can('edit_driver')): ?>
                                    <a href="#" class="btn btn-sm btn-danger" wire:click="delete(<?php echo e($item); ?>)"><?php echo e($lang->data['delete']??'Delete'); ?></a>
                                    <?php endif; ?>
                                </td> -->
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php if(count($data['drivers']) == 0): ?>
                        <?php if (isset($component)) { $__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\NoDataComponent::class, ['message' => 'No Customers were found']); ?>
<?php $component->withName('no-data-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['messageindex' => 'no_customers_found']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0)): ?>
<?php $component = $__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0; ?>
<?php unset($__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0); ?>
<?php endif; ?>
                    <?php endif; ?>
                    <div class="col-auto d-none d-sm-block">
        <h3><strong><?php echo e($lang->data['expense'] ?? 'Vehicle Assigning List'); ?></strong></h3>
    </div>
    <table class="table table-striped table-bordered mb-0">
                    <thead class="bg-secondary-light">
                        <tr>
                            <!-- <th class="tw-5"><?php echo e($lang->data['sl'] ?? 'Sl'); ?></th>
                             --><th class="tw-15"><?php echo e($lang->data['date'] ?? 'Date'); ?></th>
                            <th>Added By</th>
                
                            <th class="tw-10"><?php echo e($lang->data['vehicle_file_no'] ?? 'Vehicle File No'); ?></th>
                            <th class="tw-15"><?php echo e($lang->data['vehicle_plate_no'] ?? 'Vehicle Plate No'); ?></th>
                            <th class="tw-10"><?php echo e($lang->data['company'] ?? 'Company'); ?></th>
                            <th class="tw-10"><?php echo e($lang->data['driver'] ?? 'Driver'); ?></th>
                            <th class="tw-10"><?php echo e($lang->data['amount'] ?? 'Amount'); ?></th>
                            <th class="tw-10"><?php echo e($lang->data['agreement'] ?? 'End of Aggrement'); ?></th>
                            <th class="tw-10"><?php echo e($lang->data['status'] ?? 'Status'); ?></th>
                            <!-- <th class="tw-15"><?php echo e($lang->data['actions'] ?? 'Actions'); ?></th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data['assignings']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <!-- <td><?php echo e($loop->index + 1); ?></td>
                             --><td><?php echo e(date('d/m/Y', strtotime($item->date))); ?></td>
                            <td><?php echo e($item->user->name ?? '--'); ?></td>
                                
                            <td><?php echo e($item->vehicle->file_no); ?></td>
                            <td><?php echo e($item->vehicle->plate_no); ?></td>
                            <td><?php echo e($item->company->name); ?></td>
                            <td><?php echo e($item->driver->name); ?></td>
                            <td><?php echo e($item->amount); ?></td>
                            <td><?php echo e(date('d/m/Y', strtotime($item->end_of_time))); ?></td>
                            
                            <td>
                                <?php if($item->status == 1): ?>
                                    <span style="font-weight: bold; color: blue;">booked</span>
                                <?php else: ?>
                                    <span style="font-weight: bold; color: red;">Stop</span>
                                <?php endif; ?>
                            </td>

                            <!-- <td>
                                
                                <?php if(Auth::user()->can('delete_assigning')&& (Auth::user()->can('edit_assigning')) && ($item->status == 1)): ?>
                                    <a href="#" class="btn btn-sm btn-danger" wire:click="end_assigning(<?php echo e($item->id); ?>)"><?php echo e($lang->data['delete'] ?? 'End Assigning'); ?></a>
                                    <a href="<?php echo e(route('admin.edit_assigning',$item->id)); ?>" class="btn btn-sm btn-primary"><?php echo e($lang->data['edit'] ?? 'Edit'); ?></a>
                                 <?php else: ?>
                                    <span style="font-weight: bold; color: red;">Stop</span>
                                <?php endif; ?>

                            </td> -->
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php if(count($data['assignings']) == 0): ?>
                    <?php if (isset($component)) { $__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\NoDataComponent::class, ['message' => ''.e($lang->data['no_products_found'] ?? 'No Assigning were found..').'']); ?>
<?php $component->withName('no-data-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0)): ?>
<?php $component = $__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0; ?>
<?php unset($__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0); ?>
<?php endif; ?>
                <?php endif; ?>
                <div class="col-auto d-none d-sm-block">
            <h3><strong><?php echo e($lang->data['bus']??'Bus'); ?></strong></h3>
        </div>
<table class="table table-striped table-bordered mb-0">
                        <thead class="bg-secondary-light">
                            <tr>
                                <!-- <th class="tw-5"><?php echo e($lang->data['sl']??'Sl'); ?></th>
                                 --><th class="tw-15"><?php echo e($lang->data['registration_date']??'Registration Date'); ?></th>
                                <th>Added By</th>
                
                                
                                <th class="tw-8"><?php echo e($lang->data['file_no']??'File No.'); ?></th>
                                <th class="tw-12"><?php echo e($lang->data['plate_no']??'Plate No.'); ?></th>
                                <th class="tw-12"><?php echo e($lang->data['owner']??'Owner'); ?></th>
                                <th class="tw-12"><?php echo e($lang->data['vehicle_type']??'Vehicle Type'); ?></th>
                                <th class="tw-12"><?php echo e($lang->data['vehicle_type']??'Model'); ?></th>
                                <th class="tw-12"><?php echo e($lang->data['vehicle_type']??'Fuel Type'); ?></th>
                                <th class="tw-15"><?php echo e($lang->data['insurance_start_date']??'Istamara End Date '); ?></th>
                                <th class="tw-15"><?php echo e($lang->data['insurance_end_date']??'Insurance End'); ?></th>
                                <th class="tw-15"><?php echo e($lang->data['Status']??'Status'); ?></th>
                                <!-- <th class="tw-10"><?php echo e($lang->data['actions']??'Actions'); ?></th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['vehicles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <!-- <td><?php echo e($loop->index+1); ?></td>
                                 --><td><?php echo e(date('d/m/Y', strtotime($item->registration_date))); ?></td>
                                <td><?php echo e($item->user->name ?? '--'); ?></td>
                                
                                <td><?php echo e($item->file_no); ?></td>
                                <td><?php echo e($item->plate_no); ?></td>
                                <td><?php echo e($item->owner_name); ?></td>
                                <td><?php echo e($item->vehicle_type); ?></td>
                                <td><?php echo e($item->vehicle_model); ?></td>
                                <td><?php echo e($item->fuel_type); ?></td>
                                <td><?php echo e(date('d/m/Y', strtotime($item->istamara_end_date))); ?></td>
                                <td><?php echo e(date('d/m/Y', strtotime($item->insurance_end_date))); ?></td>
                    
                                <td>
                                    <?php if($item->status == 1): ?>
                                        <span style="font-weight: bold; color: blue;">booked</span>
                                    <?php else: ?>
                                        <span style="font-weight: bold; color: green;">Free</span>
                                    <?php endif; ?>
                                </td>
                                <!-- <td>
                                    <?php if(Auth::user()->can('edit_vehicles')): ?>
                                    <a href="#" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#EditVehicle" wire:click='edit(<?php echo e($item); ?>)'><?php echo e($lang->data['edit']??'Edit'); ?></a>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->can('delete_vehicles')): ?>
                                    <a href="#" class="btn btn-sm btn-danger" wire:click="delete(<?php echo e($item); ?>)"><?php echo e($lang->data['delete']??'Delete'); ?></a>
                                    <?php endif; ?>
                                </td> -->
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php if(count($data['vehicles']) == 0): ?>
                        <?php if (isset($component)) { $__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\NoDataComponent::class, ['message' => 'No Bus were found']); ?>
<?php $component->withName('no-data-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['messageindex' => 'no_bus_found']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0)): ?>
<?php $component = $__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0; ?>
<?php unset($__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0); ?>
<?php endif; ?>
                    <?php endif; ?>
</div>
	<?php /**PATH C:\xampp\htdocs\bus driver servise system livewire\bus-servise-system-in-livewire\resources\views/livewire/admin/home.blade.php ENDPATH**/ ?>