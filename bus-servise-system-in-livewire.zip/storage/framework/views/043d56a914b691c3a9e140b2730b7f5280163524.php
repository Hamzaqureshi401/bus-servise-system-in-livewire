<style>
.arabic-text {
    font-size: 18px; /* Adjust the font size as needed */
    
    
}
.sidebar-nav,.sidebar-content,.sidebar-brand{
background-color: #171D3F !important;
    
}
</style>
<div>
    <nav id="sidebar" class="sidebar js-sidebar">
        <div class="sidebar-content js-simplebar">
            <a class="sidebar-brand" href="<?php echo e(route('admin.dashboard')); ?>">
                <span class="sidebar-brand-text align-middle">
                    <?php echo e(getStoreName()); ?>

                     </span>
                <svg class="sidebar-brand-icon align-middle" width="32px" height="32px" viewBox="0 0 24 24"
                    fill="none" stroke="#FFFFFF" stroke-width="1.5" stroke-linecap="square" stroke-linejoin="miter"
                    color="#171D3F" class="mm-3">
                    <path d="M12 4L20 8.00004L12 12L4 8.00004L12 4Z"></path>
                    <path d="M20 12L12 16L4 12"></path>
                    <path d="M20 16L12 20L4 16"></path>
                </svg>
            </a>

            

            <ul class="sidebar-nav">
                
                <li class="sidebar-item <?php echo e(Request::is('admin/dashboard') ? 'active' : ''); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('admin.dashboard')); ?>">
                        <i class="align-middle" data-feather="sliders"></i> <span class="align-middle"><?php echo e($lang->data['dashboard'] ?? 'Dashboard'); ?></span>
                    </a>
                </li>
                        
                <?php if(Auth::user()->can('sales_report') || Auth::user()->can('day_wise_sales_report') || Auth::user()->can('item_wise_sales_report') || Auth::user()->can('customer_report')): ?>
                <li class="sidebar-item <?php echo e(Request::is('admin/reports*') ? 'active' : ''); ?>">
                    <a data-bs-target="#reports" data-bs-toggle="collapse" class="sidebar-link collapsed">
                        <i class="align-middle" data-feather="bar-chart"></i> <span class="align-middle"><?php echo e($lang->data['reports']??'Reports'); ?></span>&nbsp;
                    <span class="arabic-text">التقارير</span>
                    </a>
                    <ul id="reports" class="sidebar-dropdown list-unstyled collapse <?php echo e(Request::is('admin/reports*') ? 'show' : ''); ?>" data-bs-parent="#sidebar">
                        <?php if(Auth::user()->can('day_wise_sales_report')): ?>
                            <li class="sidebar-item <?php echo e(Request::is('admin/reports/day-wise*') ? 'active' : ''); ?> "><a class="sidebar-link" href="<?php echo e(route('admin.daywise_report')); ?>"><?php echo e($lang->data['day_wise_report']??'Assigned Bus 
                                    '); ?>&nbsp;
                                    <span class="aarabic-text">تفاصيل باصات</span>
                                    </a></li>
                        <?php endif; ?>
                        <?php if(Auth::user()->can('item_wise_sales_report')): ?>
                            <li class="sidebar-item <?php echo e(Request::is('admin/reports/item-sales*') ? 'active' : ''); ?> "><a class="sidebar-link" href="<?php echo e(route('admin.item_sales_report')); ?>"><?php echo e($lang->data['item_wise_report']??'Salary & Petrol
                                     '); ?>&nbsp;
                                     <span class="arabic-text">عاش بترول</span>
                                     </a></li>
                        <?php endif; ?>
                        <?php if(Auth::user()->can('customer_report')): ?>
                            <li class="sidebar-item <?php echo e(Request::is('admin/reports/customer*') ? 'active' : ''); ?> "><a class="sidebar-link" href="<?php echo e(route('admin.customer_report')); ?>"><?php echo e($lang->data['customer_report']??'Maintainance '); ?>&nbsp;
                            <span class="arabic-text">صيانة</span>
                            </a></li>
                        <?php endif; ?>
                        <?php if(Auth::user()->can('customer_report')): ?>
                            <li class="sidebar-item <?php echo e(Request::is('admin/reports/istamara-report*') ? 'active' : ''); ?> "><a class="sidebar-link" href="<?php echo e(route('admin.sales_report')); ?>"><?php echo e($lang->data['customer_report']??'Istamara '); ?>&nbsp;
                            <span class="arabic-text">استمارا</span>
                            </a></li>
                        <?php endif; ?>
                         <?php if(Auth::user()->can('customer_report')): ?>
                            <li class="sidebar-item <?php echo e(Request::is('admin/reports/bus-owner-report*') ? 'active' : ''); ?> "><a class="sidebar-link" href="<?php echo e(route('admin.bus_owner_report')); ?>"><?php echo e($lang->data['customer_report']??'Bus Owner '); ?>&nbsp;
                            <span class="arabic-text">مالك الحافلة</span>
                            </a></li>
                        <?php endif; ?>
                        <?php if(Auth::user()->can('customer_report')): ?>
                            <li class="sidebar-item <?php echo e(Request::is('admin/reports/company-owner-report*') ? 'active' : ''); ?> "><a class="sidebar-link" href="<?php echo e(route('admin.company_report')); ?>"><?php echo e($lang->data['customer_report']??'Company Owner '); ?>&nbsp;
                            <span class="aarabic-text">مالك شركات</span>
                            </a></li>
                        <?php endif; ?>
                        <?php if(Auth::user()->can('customer_report')): ?>
                            <li class="sidebar-item <?php echo e(Request::is('admin/reports/drivers*') ? 'active' : ''); ?> "><a class="sidebar-link" href="<?php echo e(route('admin.reports.drivers')); ?>"><?php echo e($lang->data['customer_report']??'Driver Reports '); ?>&nbsp;
                            <span class="aarabic-text">مالك شركات</span>
                            </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>
    
                <!-- Drivers -->

                <?php if(Auth::user()->can('driver_list')): ?>
                 <li class="sidebar-item <?php echo e(Request::is('admin/driver*') ? 'active' : ''); ?>">
                    <a data-bs-target="#driver" data-bs-toggle="collapse" class="sidebar-link collapsed">
                        <i class="align-middle" data-feather="bar-chart"></i> <span class="align-middle"><?php echo e($lang->data['driver']??'Drivers'); ?></span>&nbsp;
                    <span class="arabic-text"></span>
                    </a>
                    <ul id="driver" class="sidebar-dropdown list-unstyled collapse <?php echo e(Request::is('admin/driver*') ? 'show' : ''); ?>" data-bs-parent="#sidebar">

                <li class="sidebar-item <?php echo e(Request::is('admin/driver*') ? 'active' : ''); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('admin.driver')); ?>">
                        <i class="align-middle" data-feather="user"></i> <span class="align-middle"><?php echo e($lang->data['driver']??'Drivers '); ?> </span> &nbsp;
                    <span class="arabic-text">سائق</span>
                    </a>
                </li>
                <li class="sidebar-item <?php echo e(Request::is('admin/driver*') ? 'active' : ''); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('admin.assigned.drivers')); ?>">
                        <i class="align-middle" data-feather="user"></i> <span class="align-middle"><?php echo e($lang->data['driver']??'Assigned Drivers '); ?> </span> &nbsp;
                    <span class="arabic-text">سائق</span>
                    </a>
                </li>
            </ul>
        </li>
                <?php endif; ?>
                
                <!-- Vehicle -->
                <?php if(Auth::user()->can('vehicles_list')): ?>
                <li class="sidebar-item <?php echo e(Request::is('admin/vehicles*') ? 'active' : ''); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('admin.vehicles')); ?>">
                        <i class="align-middle" data-feather="user"></i> <span class="align-middle"><?php echo e($lang->data['Bus']??'Buses'); ?></span> &nbsp;
                        <span class="arabic-text">باصات</span>
                    </a>
                </li>
                <?php endif; ?>
            
                
                <!-- Companies -->
                <?php if(Auth::user()->can('company_list')): ?>
                <li class="sidebar-item <?php echo e(Request::is('admin/companies*') ? 'active' : ''); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('admin.companies')); ?>">
                        <i class="align-middle" data-feather="user"></i> <span class="align-middle"><?php echo e($lang->data['companies']??'Companies'); ?></span>&nbsp;
                    <span class="arabic-text">شركات</span>
                    </a>
                </li>
                <?php endif; ?>
                <!-- Project Assigning -->
                <?php if(Auth::user()->can('assigning_list')): ?>
                <li class="sidebar-item <?php echo e(Request::is('admin/VehicleAssignings*') ? 'active' : ''); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('admin.view_assigning')); ?>">
                        <i class="align-middle" data-feather="user"></i> <span class="align-middle"><?php echo e($lang->data['bus_assigning']??'Bus Assigning'); ?></span>
                        <span class="aarabic-text">تفاصيل باصات  </span>
                    </a>
                </li>
                <?php endif; ?>
                 <?php if(Auth::user()->can('expenses_list') || Auth::user()->can('expensetypes_list')): ?>
                    <li class="sidebar-item <?php echo e(Request::is('admin/Expense/*') ? 'active' : ''); ?>">
                        <a data-bs-target="#expense-forms" data-bs-toggle="collapse" class="sidebar-link collapsed">
                            <i class="align-middle" data-feather="check-circle"></i> <span class="align-middle"><?php echo e($lang->data['Expense'] ?? 'Salary & Petrol '); ?></span>
                            <span class="arabic-text">    معاش بترول  </span>
                        </a>
                        <ul id="expense-forms"
                            class="sidebar-dropdown list-unstyled collapse <?php echo e(Request::is('admin/expensetype/*') ? 'show' : ''); ?>"
                            data-bs-parent="#sidebar">
                            <?php if(Auth::user()->can('expensetypes_list')): ?>
                            <li class="sidebar-item <?php echo e(Request::is('admin/Expense/expensetype*') ? 'active' : ''); ?>"><a class="sidebar-link" href="<?php echo e(route('admin.expense_type')); ?>"><?php echo e($lang->data['expensetype'] ?? 'معاش بترول'); ?>&nbsp;<span class="arabic-text"></span></a></li>
                            <?php endif; ?>
                    
                            <?php if(Auth::user()->can('expenses_list')): ?>
                            <li class="sidebar-item <?php echo e(Request::is('admin/Expense/add*') ? 'active' : ''); ?>"><a class="sidebar-link" href="<?php echo e(route('admin.view_expense')); ?>"><?php echo e($lang->data['expense'] ?? 'Add Salary & Petrol'); ?>&nbsp;<span class="arabic-text"></span>معاش بترول</a> </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <!-- Maintainance & Parts Type -->
                    <?php if(Auth::user()->can('maintainance_list') || Auth::user()->can('parts_list')): ?>
                    <li class="sidebar-item <?php echo e(Request::is('admin/Maintainance/*') ? 'active' : ''); ?>">
                        <a data-bs-target="#maintainance-forms" data-bs-toggle="collapse" class="sidebar-link collapsed">
                            <i class="align-middle" data-feather="check-circle"></i> <span class="align-middle"><?php echo e($lang->data['maintainance'] ?? 'Maintainance'); ?></span>&nbsp;
                        <span class="arabic-text">صيانة</span>
                        </a>
                        <ul id="maintainance-forms"
                            class="sidebar-dropdown list-unstyled collapse <?php echo e(Request::is('admin/partstypes/*') ? 'show' : ''); ?>"
                            data-bs-parent="#sidebar">
                            <?php if(Auth::user()->can('parts_list')): ?>
                            <li class="sidebar-item <?php echo e(Request::is('admin/partstypes/*') ? 'active' : ''); ?>"><a class="sidebar-link" href="<?php echo e(route('admin.parts_type')); ?>"><?php echo e($lang->data['partstypes'] ?? 'Parts Type'); ?>&nbsp;
                            <span class="arabic-text">أجزاء الحافلة</span>
    
                            </a>
                            </li>
                            <?php endif; ?>
                    
                            <?php if(Auth::user()->can('maintainance_list')): ?>
                            <li class="sidebar-item <?php echo e(Request::is('admin/inventory/products*') ? 'active' : ''); ?>"><a class="sidebar-link" href="<?php echo e(route('admin.maintainance')); ?>"><?php echo e($lang->data['maintainance'] ?? 'Maintainance'); ?>&nbsp;
                            <span class="arabic-text">إضافة الصيانة</span>
                            
                            </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>

                <!-- Sta -->
             <?php if(Auth::user()->can('alwaqatbus_list')): ?>
               <li class="sidebar-item <?php echo e(Request::is('admin/alwaqat_buses*') ? 'active' : ''); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('admin.alwaqat_buses')); ?>">
                        <i class="align-middle" data-feather="user"></i> <span class="align-middle"><?php echo e($lang->data['Employee']??'Al Waqt Buses'); ?></span>&nbsp;
                   <span class="aarabic-text">باصات الوقت</span>
                    </a>
                </li>
                <?php endif; ?>
                
    
                <!-- Employees -->
            
                <?php if(Auth::user()->can('employee_list')): ?>
            <li class="sidebar-item <?php echo e(Request::is('admin/employee*') ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(route('admin.employees')); ?>">
                    <i class="align-middle" data-feather="user"></i> <span class="align-middle"><?php echo e($lang->data['Employee']??'Al Waqt Staff'); ?></span>&nbsp;
               <span class="arabic-text">موظف الوقت</span>
                </a>
            </li>
            <?php endif; ?>
            
            <!-- Lemousine -->
            <?php if(Auth::user()->can('limousine_list')): ?>
            <li class="sidebar-item <?php echo e(Request::is('admin/limousines*') ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(route('admin.limousine')); ?>">
                    <i class="align-middle" data-feather="user"></i> <span class="align-middle"><?php echo e($lang->data['limousine']??'Limousine'); ?></span>&nbsp;
                <span class="arabic-text">ليموزين</span>
                </a>
            </li>
            <?php endif; ?>
                <?php if(Auth::user()->can('add_staff') ||Auth::user()->can('staffs_list') ||Auth::user()->can('edit_staff') || Auth::user()->can('delete_staff')): ?>
                <li class="sidebar-item <?php echo e(Request::is('admin/staff*') ? 'active' : ''); ?>">
                    <a class="sidebar-link " href="<?php echo e(route('admin.staffs')); ?>">
                        <i class="align-middle" data-feather="users"></i> <span class="align-middle"><?php echo e($lang->data['staffs']??'Staffs'); ?></span>&nbsp;
                    <span class="arabic-text">عامل</span>
                    </a>
                </li>
                <?php endif; ?>
            
            <li class="sidebar-item <?php echo e(Request::is('admin/payments*') ? 'active' : ''); ?>">
                <a class="sidebar-link " href="<?php echo e(route('admin.payments.view')); ?>">
                    <i class="align-middle" data-feather="globe"></i> <span class="align-middle"><?php echo e($lang->data['Payments']??'Payments'); ?></span>&nbsp;
                <span class="arabic-text"></span>
                </a>
            </li>
            
            <?php if(Auth::user()->can('account_settings') || Auth::user()->can('app_settings')): ?>
            <li class="sidebar-item <?php echo e(Request::is('admin/settings*') ? 'active' : ''); ?>">
                <a data-bs-target="#settings" data-bs-toggle="collapse" class="sidebar-link collapsed">
                    <i class="align-middle" data-feather="settings"></i> <span class="align-middle"><?php echo e($lang->data['settings']??'Settings'); ?></span>&nbsp;
                <span class="arabic-text">إعدادات</span>
                </a>
                <ul id="settings" class="sidebar-dropdown list-unstyled collapse  <?php echo e(Request::is('admin/settings/*') ? 'show' : ''); ?>" data-bs-parent="#sidebar">
                    <?php if(Auth::user()->can('account_settings') ): ?>
                    <li class="sidebar-item <?php echo e(Request::is('admin/settings/account') ? 'active' : ''); ?>" ><a class="sidebar-link"
                            href="<?php echo e(route('admin.account_settings')); ?>"><?php echo e($lang->data['account_settings']??'Account Settings'); ?>&nbsp;
                            <span class="arabic-text"></span>
                            </a>
                    </li>
                    <?php endif; ?>
                    <?php if(Auth::user()->can('app_settings') ): ?>
                    <li class="sidebar-item <?php echo e(Request::is('admin/settings/app') ? 'active' : ''); ?>"><a class="sidebar-link" href="<?php echo e(route('admin.app_settings')); ?>"><?php echo e($lang->data['app_settings']??'App
                            Settings'); ?>&nbsp;
                            <span class="arabic-text"></span></a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>
            <li class="sidebar-item">
                <a class="sidebar-link" href="#" wire:click.prevent='logout'>
                    <i class="align-middle" data-feather="log-out"></i> <span class="align-middle"><?php echo e($lang->data['logout']??'Logout'); ?></span>&nbsp;
                    <span class="arabic-text">تسجيل خروج</span>
                </a>
            </li>
            </ul>
        </div>
    </nav>
</div>
<?php /**PATH C:\xampp\htdocs\bus driver servise system livewire\bus-servise-system-in-livewire\resources\views/livewire/components/sidebar.blade.php ENDPATH**/ ?>