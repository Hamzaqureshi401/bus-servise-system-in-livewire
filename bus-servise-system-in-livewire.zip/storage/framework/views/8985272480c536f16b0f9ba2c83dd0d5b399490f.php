<div>
   
<div class="row mb-2 mb-xl-3">
    <div class="col-auto d-none d-sm-block">
        <h3><strong><?php echo e($lang->data['expense'] ?? 'Salary & Petrol List'); ?></strong></h3>
    </div>
    <?php if(Auth::user()->can('add_expenses')): ?>
    <div class="col-auto ms-auto text-end mt-n1">
        <a href="<?php echo e(route('admin.add_expense')); ?>" class="btn btn-primary"><?php echo e($lang->data['new_expense'] ?? 'New Salary & Petrol Expense'); ?></a>
    </div>
    <?php endif; ?>
</div>

<div class="row">
    <div class="col-12">
        <div class="card p-0">
            <div class="card-body p-0">
                <table id="table" class="table datatable table-striped table-bordered mb-0">
                        <thead class="bg-secondary-light">
                        <tr>
                            <th class="tw-5"><?php echo e($lang->data['sl'] ?? 'Sl'); ?></th>
                            <th class="tw-15"><?php echo e($lang->data['date'] ?? 'Date'); ?></th>
                            <th class="tw-20"><?php echo e($lang->data['vehicle_plate_no'] ?? 'File no. & Company'); ?></th>
                            <th class="tw-15"><?php echo e($lang->data['expense_type'] ?? 'Driver '); ?></th>
                            <th class="tw-15"><?php echo e($lang->data['expense_type'] ?? 'Expense Type '); ?></th>
                            <th class="tw-15"><?php echo e($lang->data['amount'] ?? 'Amount'); ?></th>
                            <th class="tw-15"><?php echo e($lang->data['description'] ?? 'Description'); ?></th>
                            <th class="tw-15"><?php echo e($lang->data['actions'] ?? 'Actions'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e(date('d/m/Y', strtotime($item->date))); ?></td>
                            
                            <td><?php echo e($item->assigning->vehicle->file_no); ?>-<?php echo e($item->assigning->company->name); ?> </td>
                            <td><strong><?php echo e($item->assigning->driver->name); ?></strong></td>

                            <td><span class="badge bg-dark"><?php echo e($item->expensetype->name); ?></span></td>
                            <td><?php echo e($item->amount); ?></td>
                             <td><?php echo e($item->description); ?></td>
                           
                            <td>
                               
                                <?php if(Auth::user()->can('edit_expenses')): ?>
                                <a href="<?php echo e(route('admin.edit_expense',$item->id)); ?>" class="btn btn-sm btn-primary"><?php echo e($lang->data['edit'] ?? 'Edit'); ?></a>
                                <?php endif; ?>

                                <?php if(Auth::user()->can('delete_expenses')): ?>
                                <a href="#" class="btn btn-sm btn-danger" wire:click="delete(<?php echo e($item); ?>)"><?php echo e($lang->data['delete'] ?? 'Delete'); ?></a>
                                <?php endif; ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php if(count($expenses) == 0): ?>
                    <?php if (isset($component)) { $__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\NoDataComponent::class, ['message' => ''.e($lang->data['no_products_found'] ?? 'No Expenses were found..').'']); ?>
<?php $component->withName('no-data-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0)): ?>
<?php $component = $__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0; ?>
<?php unset($__componentOriginal39ece8d679f5a473ccb26829362d29ac712241e0); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\bus driver servise system livewire\bus-servise-system-in-livewire\resources\views/livewire/admin/expenses/view-expenses.blade.php ENDPATH**/ ?>