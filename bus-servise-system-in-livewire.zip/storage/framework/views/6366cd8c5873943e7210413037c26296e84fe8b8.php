<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bar POS">
    <meta name="author" content="B2B">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="shortcut icon" href="img/icons/icon-48x48.png" />
    <title><?php echo e(getStoreName()); ?></title>
    <link class="js-stylesheet" href="<?php echo e(asset('/assets/css/light.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link href="<?php echo e(asset('/assets/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/css/custom.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/js/toastr.min.css')); ?>" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="<?php echo e(getFavIcon()); ?>">
     <style>
        /* Hide the print button when printing */
        @media  print {
            .d-n-p {
                display: none;
            }
        }
    </style>
    <?php echo $__env->yieldPushContent('css'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body data-theme="default" data-layout="fluid" data-sidebar-position="left" data-sidebar-layout="default">
    <div class="wrapper">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.sidebar', [])->html();
} elseif ($_instance->childHasBeenRendered('t1nLCRd')) {
    $componentId = $_instance->getRenderedChildComponentId('t1nLCRd');
    $componentTag = $_instance->getRenderedChildComponentTagName('t1nLCRd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('t1nLCRd');
} else {
    $response = \Livewire\Livewire::mount('components.sidebar', []);
    $html = $response->html();
    $_instance->logRenderedChild('t1nLCRd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <div class="main">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.header', [])->html();
} elseif ($_instance->childHasBeenRendered('BnkWXUt')) {
    $componentId = $_instance->getRenderedChildComponentId('BnkWXUt');
    $componentTag = $_instance->getRenderedChildComponentTagName('BnkWXUt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BnkWXUt');
} else {
    $response = \Livewire\Livewire::mount('components.header', []);
    $html = $response->html();
    $_instance->logRenderedChild('BnkWXUt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <main class="content p-3">
                    <div class="container-fluid p-0">
                        <?php echo e($slot); ?>

                    </div>
                </main>
        </div>
    </div>
    <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/toastr.min.js')); ?>"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> -->
<script type="text/javascript">
    "use strict";
       
       $(document).ready(function () {
            $('.print').on('click', function () {
                window.print();
                setTimeout(function() {
                    window.close();
                }, 1);
            });
        });
   </script>
    <script>
        "use strict"
        Livewire.on('closemodal', () => {
            $('.modal').modal('hide');
            $('.modal-backdrop').remove();
            $('body').removeClass('modal-open');
            $('body').removeAttr('style');
        })
    </script>
    <script>
        "use strict";
        Livewire.on('reloadpage', () => {
            window.location.reload();
        })
    </script>
    <script>
        "use strict";
        window.addEventListener('alert', event => {
            toastr[event.detail.type](event.detail.message, event.detail.title ?? '');
            toastr.options = {
                "closeButton": true,
                "progressBar": true,
            }
        });
        <?php if(Session::has('message')): ?>
            toastr.info("<?php echo e(Session::get('message')); ?>");
        <?php endif; ?>
    </script>
    <script>
        $(document).ready(function () {
            $('#table').DataTable();
        });
        $('#table').dataTable({
            "lengthMenu": [15, 25, 50, 100]
        });

        document.addEventListener('livewire:load', function () {
            Livewire.on('initDataTables', function () {
                $('#table').DataTable();
            });
        });
    </script>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\bus driver servise system livewire\bus-servise-system-in-livewire\resources\views/layouts/app.blade.php ENDPATH**/ ?>