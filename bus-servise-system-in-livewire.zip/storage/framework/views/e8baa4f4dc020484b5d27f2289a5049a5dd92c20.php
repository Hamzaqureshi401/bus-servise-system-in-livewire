<div>
		<main class="d-flex w-100 h-100">
		<div class="container d-flex flex-column">
			<div class="row vh-100">
				<div class="col-sm-10 col-md-8 col-lg-4 mx-auto d-table h-100">
					<div class="d-table-cell align-middle">
						<center>
                            <div>
                                <?php
                                $logo = '/uploads/logo/1698697749.png';
                                ?>
                                <img src="<?php echo e($logo); ?>" alt="Company Logo" style="width: auto; height: auto; max-width: 60%; max-height: 60%;">
                            </div>
                       </center>
<br>
						<div class="card">
							<div class="card-body">
								<div class="m-sm-4">
									<div class="text-center mb-4">
										<h1><?php echo e(getStoreName()); ?></h1>
									</div>
									<form>
										<div class="mb-3">
											<label class="form-label"><?php echo e($lang->data['email']??'Email'); ?></label>
											<input class="form-control form-control-lg" type="email" name="email" placeholder="<?php echo e($lang->data['enter_email']??'Enter your email'); ?>" wire:model='email'/>
											<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<span class="text-danger"><?php echo e($message); ?></span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
										<div class="mb-3">
											<label class="form-label"><?php echo e($lang->data['password']??'Password'); ?></label>
											<input class="form-control form-control-lg " type="password" name="password" placeholder="<?php echo e($lang->data['enter_password']??'Enter your password'); ?>" wire:model='password'/>
											<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<span class="text-danger d-block"><?php echo e($message); ?></span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											<?php $__errorArgs = ['login_error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<span class="text-danger d-block"><?php echo e($message); ?></span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
										<div>
											<label class="form-check">
												<input class="form-check-input" type="checkbox" value="remember-me" name="remember-me" checked>
												<span class="form-check-label">
													<?php echo e($lang->data['remember_me_next']??'Remember me next time'); ?>

												</span>
											</label>
										</div>
										<div class="text-center mt-3">
											<a href="#" class="btn btn-lg btn-primary" wire:click.prevent='login'><?php echo e($lang->data['sign_in']??'Sign in'); ?></a>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</main>
</div><?php /**PATH C:\xampp\htdocs\bus driver servise system livewire\bus-servise-system-in-livewire\resources\views/livewire/login.blade.php ENDPATH**/ ?>