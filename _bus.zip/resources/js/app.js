require('./bootstrap');
import Alpine from 'alpinejs'
import Swal from 'sweetalert2'

window.Alpine = Alpine
window.Swal = Swal

Alpine.start()