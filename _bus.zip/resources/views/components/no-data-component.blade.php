<div>
    <div class="empty w-100 d-flex justify-content-center align-items-center flex-column h-100 ">
        <div class="empty-img"><img
                src="{{ asset('/assets/img/nodata.png') }}" height="128"
                alt="">
        </div>
        <p class="empty-title">{{ $message}}</p>
    </div>
</div>