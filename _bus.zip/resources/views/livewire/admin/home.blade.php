	<center>
                            <div>
                                @php
                                $logo = '/uploads/logo/1698697749.png';
                                @endphp
                                <img src="{{ $logo }}" alt="Company Logo" style="width: auto; height: auto; max-width: 60%; max-height: 60%;">
                            </div>
                       </center>
<br>